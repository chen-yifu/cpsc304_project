package drone.delivery.com.company.Model;

import java.sql.*;
import java.util.ArrayList;

public class OrderContainsItem {
    protected Statement state = null;
    protected Connection conn = null;
    public ResultSet resultSet = null;

    public OrderContainsItem(Statement mainState, Connection mainConn) {
        try {
            conn = mainConn;
            state = mainState;
        } catch (Exception e) {
            System.out.println(e);
            // error handling
        }
    }

    public void create(int order_id, String item_fullname, int quantity) throws SQLException {
        String sql = "insert into Order_Contains_Item values(?,?,?)";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1,order_id);
        ps.setString(2,item_fullname);
        ps.setInt(3,quantity);
        ps.executeQuery();
        conn.commit();
    }



    public void delete(int order_id, String item_fullname) throws SQLException {
        String sql = "delete from Order_Contains_Item where order_id = ? and item_fullname = ?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1,order_id);
        ps.setString(2,item_fullname);
        ps.executeQuery();
        conn.commit();
    }
    public void update(int order_id, String item_fullname, int quantity) throws SQLException {
        String sql = "update Order_Contains_Item set quantity = ? where order_id = ? and item_fullname = ?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1,quantity);
        ps.setInt(2,order_id);
        ps.setString(3,item_fullname);
        ps.executeQuery();
        conn.commit();
    }

    // select customer with id and name who buy the items whose quantity >= bound so that it can upgrade the VIP_level
    public void returnResultSet() throws SQLException {
        while(resultSet.next()) {
            System.out.println(resultSet.getString("customer_id") + ", " +
                    resultSet.getString("fullname"));
        }

    }
}

