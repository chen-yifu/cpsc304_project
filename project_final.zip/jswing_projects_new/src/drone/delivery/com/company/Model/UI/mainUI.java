package drone.delivery.com.company.Model.UI;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import static drone.delivery.com.company.Main.mainFrame;

public class mainUI {
    public JPanel panel1;
    private JButton droneAgentButton;
    private JButton sellerButton;
    private JButton customer;
    private JButton custRegisterationButton;
    private JButton sellerManagerButton;

    public mainUI() {

        customer.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                mainFrame.getContentPane().removeAll();
                mainFrame.repaint();
                mainFrame.setContentPane(new drone.delivery.com.company.Model.UI.customerLogin().panel1);
                mainFrame.repaint();
                mainFrame.setVisible(true);
            }
        });


        custRegisterationButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mainFrame.getContentPane().removeAll();
                mainFrame.repaint();
                mainFrame.setContentPane(new customerRegister().panel1);
                mainFrame.repaint();
                mainFrame.setVisible(true);
            }
        });
        sellerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mainFrame.getContentPane().removeAll();
                mainFrame.repaint();
                mainFrame.setContentPane(new drone.delivery.com.company.Model.UI.seller().panel1);
                mainFrame.repaint();
                mainFrame.setVisible(true);
            }
        });
        droneAgentButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mainFrame.getContentPane().removeAll();
                mainFrame.repaint();
                mainFrame.setContentPane(new drone.delivery.com.company.Model.UI.agent().panel1);
                mainFrame.repaint();
                mainFrame.setVisible(true);
            }
        });
        sellerManagerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mainFrame.getContentPane().removeAll();
                mainFrame.repaint();
                mainFrame.setContentPane(new drone.delivery.com.company.Model.UI.sellerManager().panel1);
                mainFrame.repaint();
                mainFrame.setVisible(true);
            }
        });
    }
}
