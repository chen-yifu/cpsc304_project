package drone.delivery.com.company.Model.UI;

import drone.delivery.com.company.Model.Customer;
import drone.delivery.com.company.Model.Store;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import static drone.delivery.com.company.Main.mainFrame;
import static drone.delivery.com.company.Main.userController;

public class seller {
    public JPanel panel1;
    private JButton deleteACustomerButton;
    private JButton updateACustomerButton;
    private JButton manageStoreItemsButton;
    private JButton homeButton;
    private JList customersList;
    private JTextField minOrderField;
    private JButton applyFilterButton;

    public seller() {
        updateACustomerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mainFrame.getContentPane().removeAll();
                mainFrame.repaint();
                mainFrame.setContentPane(new sellerUpdateCustomer().panel1);
                mainFrame.repaint();
                mainFrame.setVisible(true);
            }
        });
        deleteACustomerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mainFrame.getContentPane().removeAll();
                mainFrame.repaint();
                mainFrame.setContentPane(new sellerDeleteCustomer().panel1);
                mainFrame.repaint();
                mainFrame.setVisible(true);
            }
        });
        homeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mainFrame.getContentPane().removeAll();
                mainFrame.repaint();
                mainFrame.setContentPane(new mainUI().panel1);
                mainFrame.repaint();
                mainFrame.setVisible(true);
            }
        });
//        manageStoreItemsButton.addActionListener(new ActionListener() {
//            @Override
//            public void actionPerformed(ActionEvent e) {
//                mainFrame.getContentPane().removeAll();
//                mainFrame.repaint();
//                mainFrame.setContentPane(new sellerDashboard().panel1);
//                mainFrame.repaint();
//                mainFrame.setVisible(true);
//            }
//        });
        applyFilterButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                DefaultListModel listModel = new DefaultListModel();
                try {
                    ArrayList<Customer> countByQuantity = userController.countByQuantity(Integer.parseInt(minOrderField.getText()));
                    for (Customer c : countByQuantity) {
                        listModel.addElement(c.getCid() + " " + c.getCname());
                    }
                    if (countByQuantity.size() == 0) {
                        listModel.addElement("None");
                    }
                } catch (Exception ex) {
                    System.out.println("Error occurred.");
                }
                customersList.setModel(listModel);
                customersList.revalidate();
                customersList.repaint();

            }
        });
    }
}
