package drone.delivery.com.company.Model.UI;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import static drone.delivery.com.company.Main.mainFrame;

public class sellerDashboard {
    protected JPanel panel1;
    private JScrollPane itemsPane;
    private JButton createItemButton;
    private JButton homeButton;
    private JButton updateItemButton;


    public sellerDashboard() {
        homeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mainFrame.getContentPane().removeAll();
                mainFrame.repaint();
                mainFrame.setContentPane(new mainUI().panel1);
                mainFrame.repaint();
                mainFrame.setVisible(true);
            }
        });
    }
}
