package drone.delivery.com.company.Model.UI;

import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class JSwingBasic extends JFrame {
    private static final long serialVersionUID = -7123412342425231234L;

    public JSwingBasic() {
        super("JSwing fire");
        setBounds(100, 100, 300, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        Container contentPane = this.getContentPane();
        JPanel pane = new JPanel();
        JButton buttonStart = new JButton("start");
        final JTextField textPeriod = new JTextField(10);
        JLabel labelPeriod = new JLabel("Input label: ");
        JCheckBox checkboxIsRandom = new JCheckBox("fire it!");
        checkboxIsRandom.addChangeListener(new ChangeListener() {
            @Override
            public void stateChanged(ChangeEvent e) {
                if (((JCheckBox)e.getSource()).isSelected()) {
                    textPeriod.setText("it is fired!");
                    textPeriod.setEnabled(false);
                } else {
                    textPeriod.setText("");
                    textPeriod.setEnabled(true);
                }

            }
        });

        buttonStart.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JButton btn = (JButton) e.getSource();
                if (btn.getText().equals("start")) {
                    //JdbcExample jdbcUser = new JdbcExample(e.id);
                    //jdbcUser.showUser();
////
//                    jdbcUser.getFoodList();
//                    jdbcUser.getStore();
                    textPeriod.setText("it is starting");
                    textPeriod.setEnabled(false);

                }
            }
        });




        buttonStart.setMnemonic(1);

        pane.add(buttonStart);
        pane.add(labelPeriod);
        pane.add(textPeriod);
        pane.add(checkboxIsRandom);
        contentPane.add(pane);

        setVisible(true);
    }
}
