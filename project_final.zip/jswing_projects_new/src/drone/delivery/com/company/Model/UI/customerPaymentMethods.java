package drone.delivery.com.company.Model.UI;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import static drone.delivery.com.company.Main.mainFrame;

public class customerPaymentMethods {
    protected JPanel panel1;
    private JTextField paymentMethodIDTextField;
    private JButton payButton;
    private JButton backButton;
    private JLabel successMessage;
    private JTable paymentMethodsTable; // TODO: update this table to show Payment Methods from database

    public customerPaymentMethods() {

        paymentMethodIDTextField.setVisible(false);

        payButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // TODO: implement method to show "Payment success" message by making un-hiding "successMessage"
                // if payment success -> paymentMethodIDTextField.setVisible(true);
            }
        });
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mainFrame.getContentPane().removeAll();
                mainFrame.repaint();
                mainFrame.setContentPane(new customer().panel1);
                mainFrame.repaint();
                mainFrame.setVisible(true);
            }
        });
    }
}
