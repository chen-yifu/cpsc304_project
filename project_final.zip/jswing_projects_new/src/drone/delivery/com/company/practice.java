package drone.delivery.com.company;

public class practice {

    public practice(){
    }

    public void print(){
        System.out.println("Database");
    }

}
