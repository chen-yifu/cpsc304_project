package drone.delivery.com.company.Controller;

import java.sql.*;

public class ConnectController {

    private Connection conn = null;
    private Statement state = null;

    public ConnectController() {}

    public void connect(String url, String username, String password) {
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection(url, username, password);
            conn.setAutoCommit(false);
            System.out.println("MySQL is connected\n");
            state = conn.createStatement();
        } catch (Exception e) {
            System.out.println("Message: " + e.getMessage());
        }
    }

    public Connection getConnection() {
        return this.conn;
    }

    public Statement getStatement() {
        return this.state;
    }

    public void closeConnection(Connection conn, Statement state) throws SQLException {
        if (state != null) {
            state.close();
        }
        if (conn != null) {
            conn.close();
        }
    }
}
