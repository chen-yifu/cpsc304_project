package drone.delivery.com.company.Controller;

import drone.delivery.com.company.Model.Customer;
import drone.delivery.com.company.Model.Store;
import drone.delivery.com.company.Model.StoreStaff;

import java.sql.*;
import java.util.ArrayList;

public class StoreStaffController {
    private Statement st;
    private Connection conn;
    private StoreStaff staff;


    public StoreStaffController(Statement st, Connection conn) {
        this.st = st;
        this.conn = conn;
        staff = new StoreStaff(st,conn);
    }


    // second choice for join
    // getStoreInfo according to store_id
//    public ArrayList<Store> getStores(int store_id) throws SQLException {
//        //Store store = new Store();
//        ArrayList<Store> stores = new ArrayList<>();
//        String sql = "Select * from Store_Address sa join Store_Contact_Info sci ON sa.fullname = sci.fullname and sa.phone = sci.phone join Store_Operating_Hour soh on soh.fullname = sci.fullname and soh.address = sa.address where store_id = ?";
//        ResultSet rs;
//        PreparedStatement ps =conn.prepareStatement(sql);
//        ps.setInt(1,store_id);
//        rs = ps.executeQuery();
//        rs.next();
//
//        return stores;
//    }
//
//    private void addToStores(ArrayList<Store> stores, ResultSet rs) throws SQLException{
//        while(rs.next()) {
//            Store store = new Store();
//            store.setStore_id(rs.getInt("store_id"));
//            store.setAddress(rs.getString("address"));
//            store.setFullname(rs.getString("fullname"));
//            store.setClose_hour(rs.getString("close_hour"));
//            store.setOpen_hour(rs.getString("open_hour"));
//            store.setPhone(rs.getString("phone"));
//            store.setRating(rs.getInt("rating"));
//            store.setType(rs.getString("type"));
//            stores.add(store);
//        }
//    }

//    public void deleteInvalidCustomer(int customer_id) {
//        Customer customer = new Customer(st,conn);
//        try {
//            customer.delete(customer_id);
//        } catch (Exception e) {
//            System.out.println(e);
//        }
//    }

//    public void updateCustomerInfo(int id, String fullname, String password,
//                                   String phone, String address) {
//        Customer customer = new Customer(st,conn);
//        try{
//            customer.update(id,fullname,password,phone,address);
//        } catch (Exception e) {
//            System.out.println(e);
//        }
//    }

    // select the name of staff who fulfill all the orders
    // Division
    public ArrayList<StoreStaff> getTheStaffFulfilledAllOrders() throws SQLException {
        ArrayList<StoreStaff> staffs = new ArrayList<>();
        ResultSet resultSet;
        String sql = "select s.staff_fullname from Store_Staff s where not exists(select o.order_id from Orders o where not exists(select sf.staff_id from Staff_Fullfills_Order sf where s.staff_id = sf.staff_id and sf.order_id = o.order_id))";
        PreparedStatement ps = conn.prepareStatement(sql);
        resultSet = ps.executeQuery();
        addToStaffs(staffs,ps,resultSet);
        return staffs;
    }

    public void addToStaffs(ArrayList staffs, PreparedStatement ps, ResultSet rs) throws SQLException {
        while(rs.next()) {
            StoreStaff staff = new StoreStaff(ps,conn);
            staff.setStaff_name(rs.getString("staff_fullname"));
            staffs.add(staff);
        }
    }
}
