package drone.delivery.com.company.Controller;

import drone.delivery.com.company.Model.*;

import java.sql.*;
import java.util.ArrayList;

public class StoreController {
    protected Statement state = null;
    protected Connection conn = null;

    public StoreController(Statement mainState, Connection mainConn) {
        try {
            conn = mainConn;
            state = mainState;
        } catch (Exception e) {
            System.out.println(e);
            // error handling
        }
    }

//    public void createStoreStaff(String fullname, String password, String phone, String email, String address) throws SQLException{
//        //if ()
//        new StoreStaff(state, conn).create(fullname, password, phone, email, address);
//    }

    public void createStore(int store_id, String phone, String fullname, String address, String close_hour, String open_hour, String type) throws SQLException {
        new StoreAddress(state, conn).create(fullname, phone, address);
        new StoreOperatingHour(state, conn).create(fullname, address, close_hour, open_hour, 0, type);
        new StoreContactInfo(state, conn).create(store_id, fullname, phone);
    }

    // public void updateStore()

    public ResultSet getListOfStoresByStaffId(int staff_id) throws SQLException {
        StoreStaffOperatesStore ssos = new StoreStaffOperatesStore(state, conn);
        ssos.readByStaffId(staff_id);
        return ssos.resultSet;
    }



//    private void addToStores(ArrayList<Store> stores, ResultSet rs) throws SQLException {
//        while (rs.next()) {
//            Store store = new Store();
//            store.setStore_id(rs.getInt("store_id"));
//            store.setAddress(rs.getString("address"));
//            store.setFullname(rs.getString("fullname"));
//            store.setClose_hour(rs.getString("close_hour"));
//            store.setOpen_hour(rs.getString("open_hour"));
//            store.setPhone(rs.getString("phone"));
//            store.setRating(rs.getInt("rating"));
//            store.setType(rs.getString("type"));
//            stores.add(store);
//        }
//    }
}
