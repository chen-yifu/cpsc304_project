package drone.delivery.com.company.Controller;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

public class OrderController {
    private Statement state = null;
    private Connection conn = null;
    private ResultSet rs;

    public OrderController(Statement state, Connection conn) {
        this.state = state;
        this.conn = conn;
    }

    public void getOrders() {

    }


}
