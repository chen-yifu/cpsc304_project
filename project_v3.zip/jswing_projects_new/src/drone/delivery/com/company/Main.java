package drone.delivery.com.company;
import drone.delivery.com.company.Controller.*;
import drone.delivery.com.company.Model.Customer;
import drone.delivery.com.company.Model.DroneAgent;
import drone.delivery.com.company.Model.Store;
import drone.delivery.com.company.Model.StoreStaff;
import drone.delivery.com.company.Model.UI.mainUI;

import javax.swing.*;
import java.sql.*;
import java.util.ArrayList;


public class Main {
    public static JFrame mainFrame;
    public static Statement st;
    public static Connection conn;
    public static CustomerController userController;
    public static StoreStaffController staffController;
    public static DroneAgentController agentController;

    public static void main(String[] args) {
        ConnectController controller = new ConnectController();
        String url = "jdbc:mysql://localhost:3306/drone_delivery?serverTimezone=UTC";
        String username = "root";
        String password = "0000";
        controller.connect(url,username,password);
        st = controller.getStatement();
        conn = controller.getConnection();

        userController = new CustomerController(st,conn);
        staffController = new StoreStaffController(st,conn);
        agentController = new DroneAgentController(st,conn);


        // test1 Insert
       //userController.register("Michael","mike123","604-444-1000","michael@gmail.com","2222 West Mall, Vancouver");
        //userController.register("Mike","mike123","604-444-2222","mike.hustler@gmail.com","2222 West Mall, Vancouver");


        // test2 Selection
//        Customer cus = userController.login("mike@gmail.com","mike123");
//        System.out.println(cus.getEmail());
//        System.out.println(cus.getPassword());

        //test3 delete
//        userController.deleteInvalidCustomer(8);
//        userController.deleteInvalidCustomer(9);

         //test4 update
       //userController.updateCustomerInfo(5,"Ivring Lee","lee981221","778-444-1234","111 West Mall, Vancouver");


//    // test5 projection
//        String res = userController.getTheOrderIDAndDeliverStatus(2);
//        System.out.println("projection test: "+ res);
//
//    // test6 join Customer.showPaymentID ->  Payment.getPaymentMethodByPaymentID
//        System.out.println("join test: " + userController.showPaymentMethod(1));
//
//    // test7 aggregation
//        ArrayList<Store> stores = new ArrayList<>();
//        try {
//            stores = userController.getStoreByAvgCalorie(110,120);
//        } catch (SQLException e) {
//            System.out.println(e);
//        }
//        for (Store store: stores) {
//            System.out.println(store.getFullname());
//        }
//        try {
//            PreparedStatement ps = conn.prepareStatement("src/drone/delivery/com/company/initialization_script/initialization_script.sql");
//            ps.executeQuery();
//            System.out.println("Database is initialized.");
//        } catch (Exception e) {
//            System.out.println(e.getMessage());
//            System.out.println("Database initialization failed.");
//        }
//
//    // test8 nested-subquery
//    ArrayList<Customer> cuss;
//        try {
//        cuss = userController.countByQuantity(5);
//        System.out.println("nested-sub test: " + cuss.get(0).getCname());
//    } catch (Exception e) {
//        System.out.println();
//    }
//
//    // test9 division
//    ArrayList<StoreStaff> staffs;
//        try{
//        staffs = staffController.getTheStaffFulfilledAllOrders();
//        System.out.println("division test: " + staffs.get(0).getStaff_name());
//    } catch (Exception e){
//        System.out.println(e);
//    }

        // test 10 Division in DroneAgent
//        ArrayList<DroneAgent> agents;
//        try{
//            agents = agentController.getTheAgentNameWhoOperatesAllDrones();
//            System.out.println(agents.get(0).getFullname());
//        } catch (Exception e) {
//            System.out.println(e);
//        }


        // extra: test for getStores()  join
//        ArrayList<Store> stores = new ArrayList<>();
//        try {
//            stores = userController.getStores();
//        } catch (SQLException e) {
//            System.out.println(e);
//        }
//        for (Store store: stores) {
//            System.out.println(store.getStore_id() + " " + store.getFullname() + " " + store.getFullname() + " "
//                    + store.getAddress() + " " + store.getOpen_hour() + " " + store.getClose_hour() + " "
//            + store.getRating() + " " + store.getType());
//        }
        // Create UI
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                mainFrame = new JFrame("Drone Food Delivery");
                mainFrame.setContentPane(new mainUI().panel1);
                mainFrame.setSize(1200,500);
                mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                mainFrame.setVisible(true);
            }
        });
    }

}
