package drone.delivery.com.company.Model;

import java.sql.*;

public class AgentOperatesDrone {
    protected Statement state = null;
    protected Connection conn = null;
    public ResultSet resultSet = null;

    public AgentOperatesDrone(Statement mainState, Connection mainConn) {
        try {
            conn = mainConn;
            state = mainState;
        } catch (Exception e) {
            System.out.println(e);
            // error handling
        }
    }


    public void create(int drone_id, int agent_id) throws SQLException {
        String sql = "insert into Agent_Operates_Drone values(?,?)";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1,drone_id);
        ps.setInt(2,agent_id);
        ps.executeQuery();
        conn.commit();
    }

    public void readByDroneID(int drone_id) throws SQLException {
        String sql = "select * from Agent_Operates_Drone where drone_id = ?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1,drone_id);
        resultSet = ps.executeQuery();

    }
    public void readByDroneAgentID(int drone_Agent_id) throws SQLException {
        String sql = "select * from Agent_Operates_Drone where drone_Agent_id = ?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1,drone_Agent_id);
        resultSet = ps.executeQuery();
    }
    public void delete(int drone_id) throws SQLException {
        String sql = "delete from Agent_Operates_Drone where drone_id = ?";
        PreparedStatement ps= conn.prepareStatement(sql);
        ps.setInt(1,drone_id);
        ps.executeQuery();
        conn.commit();
    }
    public void update(int drone_Agent_id, int drone_id) throws SQLException {
        String sql = "update Agent_Operates_Drone set drone_Agent_id = ? where drone_id =?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1,drone_Agent_id);
        ps.setInt(2,drone_id);
        ps.executeQuery();
        conn.commit();
    }

    public void returnResultSet() throws SQLException{
        while(resultSet.next()) {
            System.out.println(resultSet.getInt("drone_Agent_id") + ", " + resultSet.getInt("drone_id"));
        }
    }
}
