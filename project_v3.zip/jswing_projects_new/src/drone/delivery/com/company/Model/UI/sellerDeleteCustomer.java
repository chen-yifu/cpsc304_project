package drone.delivery.com.company.Model.UI;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import static drone.delivery.com.company.Main.mainFrame;
import static drone.delivery.com.company.Main.userController;

public class sellerDeleteCustomer {
    public JPanel panel1;
    private JButton deleteCustomerButton;
    private JTextField customerIDTextField;

    public sellerDeleteCustomer() {
        deleteCustomerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    userController.deleteInvalidCustomer(Integer.parseInt(customerIDTextField.getText()));
                    System.out.println("Deleted customer.");
                } catch (Exception ex) {
                    System.out.println("Delete customer failed.");
                }
                mainFrame.getContentPane().removeAll();
                mainFrame.repaint();
                mainFrame.setContentPane(new seller().panel1);
                mainFrame.repaint();
                mainFrame.setVisible(true);
                System.out.println("Customer deleted.");
            }
        });
    }
}
