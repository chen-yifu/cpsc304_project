package drone.delivery.com.company.Model;

import java.sql.*;

public class Item {
    private Statement state = null;
    private Connection conn = null;
    public ResultSet resultSet = null;

    private int calorie;

    public Item(Statement mainState, Connection mainConn) {
        try {
            conn = mainConn;
            state = mainState;
        } catch (Exception e) {
            System.out.println(e);
            // error handling
        }
    }


    public void create(String fullname, int store_id, String ingredients, double calorie, double price) throws SQLException {
        String sql = "Insert Into Item values(?, ?, ?, ?, ?)";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setString(1, fullname);
        ps.setInt(2, store_id);
        ps.setString(3, ingredients);
        ps.setDouble(4, calorie);
        ps.setDouble(5, price);
        ps.executeQuery();
        conn.commit();
    }

    // As a customer, i would like to select a store which can ensure that the items' avg calorie should be in my accepted range
    // select a store with its name and store_id, which can ensure that the items' avg calorie in this store is in the given range
    public ResultSet selectStoreByAvgCalorie(int low_calorie, int high_calorie) throws SQLException {
        String sql = "select sc.fullname as store_name from Item i, Store_Contact_Info sc where i.store_id = sc.store_id group by store_name having avg(calorie) >= ? and avg(calorie) <= ?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1,low_calorie);
        ps.setInt(2,high_calorie);
        resultSet = ps.executeQuery();
        if (resultSet.next()) {
            return resultSet;
        }
        return null;
    }
    public void delete(String fullname, int store_id) throws SQLException {
        String sql = "delete from Item where fullname = ? and store_id = ?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setString(1,fullname);
        ps.setInt(2,store_id);
        ps.executeQuery();
        conn.commit();
    }
    public void updatePrice(String fullname, int store_id, int price) throws SQLException {
        String sql = "update Item set price = ? where fullname = ? and store_id = ? ";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1,price);
        ps.setString(2,fullname);
        ps.setInt(3,store_id);
        ps.executeQuery();
        conn.commit();
    }

    public void returnResultSet() throws SQLException {
        while(resultSet.next()) {
            System.out.println(resultSet.getString("store_name") + ", " +
                    resultSet.getInt("store_id") + ", " + resultSet.getString("item_name"));
        }

    }

    public int getCalorie() {
        return calorie;
    }


}


