package drone.delivery.com.company.Model.UI;

import drone.delivery.com.company.Model.Store;
import drone.delivery.com.company.Model.StoreStaff;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import static drone.delivery.com.company.Main.*;

public class sellerManager {
    private JList staffList;
    private JButton submitButton;
    private JButton button1;
    public JPanel panel1;

    public sellerManager() {
        submitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                DefaultListModel listModel = new DefaultListModel();
                try {
                    ArrayList<StoreStaff> staffs = staffController.getTheStaffFulfilledAllOrders();
                    for (StoreStaff s : staffs) {
                            String row = "name: %s";
                            row = String.format(row, s.getStaff_name());
                            listModel.addElement(row);
                        }
                    System.out.println("Showing all staff who fulfilled all orders.");
                } catch (Exception ex) {
                    System.out.println("Error occurred.");
                }
                staffList.setModel(listModel);
                staffList.revalidate();
                staffList.repaint();

            }
        });
        button1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mainFrame.getContentPane().removeAll();
                mainFrame.repaint();
                mainFrame.setContentPane(new mainUI().panel1);
                mainFrame.repaint();
                mainFrame.setVisible(true);
            }
        });
    }
}
