package drone.delivery.com.company.Model;

public class Store {
    private int store_id;
    private String fullname;
    private String phone;
    private String address;
    private String open_hour;
    private String close_hour;
    private int rating;
    private String type;

    public Store(int store_id, String fullname, String phone, String address, String open_hour, String close_hour, int rating, String type) {
        this.store_id = store_id;
        this.fullname = fullname;
        this.phone = phone;
        this.address = address;
        this.open_hour = open_hour;
        this.close_hour = close_hour;
        this.rating = rating;
        this.type = type;
    }

    public Store() {}

    public int getStore_id() {
        return store_id;
    }

    public String getFullname() {
        return fullname;
    }

    public String getPhone() {
        return phone;
    }

    public String getAddress() {
        return address;
    }

    public String getOpen_hour() {
        return open_hour;
    }

    public String getClose_hour() {
        return close_hour;
    }

    public int getRating() {
        return rating;
    }

    public String getType() {
        return type;
    }

    public void setStore_id(int store_id) {
        this.store_id = store_id;
    }

    public void setFullname(String fullname) {
        this.fullname = fullname;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public void setOpen_hour(String open_hour) {
        this.open_hour = open_hour;
    }

    public void setClose_hour(String close_hour) {
        this.close_hour = close_hour;
    }

    public void setRating(int rating) {
        this.rating = rating;
    }

    public void setType(String type) {
        this.type = type;
    }

    @Override
    public boolean equals(Object obj) {
        Store that = (Store) obj;
        return this.fullname.equals((that.getFullname()));
    }
}
