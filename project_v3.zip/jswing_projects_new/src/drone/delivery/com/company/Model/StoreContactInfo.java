package drone.delivery.com.company.Model;

import java.sql.*;

public class StoreContactInfo {
    private Statement state = null;
    private Connection conn = null;
    public ResultSet resultSet = null;

    private String storeName;
    private int store_id;

    public StoreContactInfo(Statement mainState, Connection mainConn) {
        try {
            conn = mainConn;
            state = mainState;
        } catch (Exception e) {
            System.out.println(e);
            // error handling
        }
    }

    public void create(int id, String fullname, String phone) throws SQLException {
        String sql = "Insert Into Store_Contact_Info values(?, ?, ?)";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1, id);
        ps.setString(2, fullname);
        ps.setString(3, phone);
        ps.executeQuery();
        conn.commit();
    }

    public void read(int id, String phone, String fullname) throws SQLException {
        String sql = "Select * from  Store_Contact_Info where id=? and phone =? and fullname =?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1, id);
        ps.setString(2, phone);
        ps.setString(3, fullname);
        resultSet = ps.executeQuery();
    }

    public void returnResultSet() throws SQLException {
        resultSet.next();
        System.out.println(resultSet.getString("address") + "," + resultSet.getString("open_hour") + ","
                + resultSet.getString("close_hour") + "," + resultSet.getString("rating")
                + " ," + resultSet.getString("type"));
    }

    public String getStoreName() {
        return storeName;
    }

    public void setStoreName(String storeName) {
        this.storeName = storeName;
    }

    public int getStore_id() {
        return store_id;
    }

    public void setStore_id(int store_id) {
        this.store_id = store_id;
    }
}

