package drone.delivery.com.company.Model;

import javax.print.DocFlavor;
import java.sql.*;

public class StoreStaffOperatesStore {
    protected Statement state = null;
    protected Connection conn = null;
    public ResultSet resultSet = null;

    public StoreStaffOperatesStore(Statement mainState, Connection mainConn) {
        try {
            conn = mainConn;
            state = mainState;
        } catch (Exception e) {
            System.out.println(e);
            // error handling
        }
    }

    public void create(int staffid, int storeid, String since, String fullname, String phone) throws SQLException {
        String sql = "insert into Store_Staff_Operates_Store values(staff_id = ?, store_id =?, since =?, fullname = ?, phone =?)";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1, staffid);
        ps.setInt(2, storeid);
        ps.setString(3, since);
        ps.setString(4, fullname);
        ps.setString(5, phone);
        ps.executeQuery();
        conn.commit();
    }

    public void update(int staffid, int storeid, String fullname, String phone) throws SQLException {
        String sql ="update Store_Staff_Operates_Store set fullname = ?, phone = ? where staffid =? and storeid =? ";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setString(1,fullname);
        ps.setString(2,phone);
        ps.setInt(3, staffid);
        ps.setInt(4,storeid);
        ps.executeUpdate();
    }
    public void readByStaffId(int id) throws SQLException {
        String sql = "Select * from Store_Staff_Operates_Store where staff_id = ?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1,id);
        resultSet = ps.executeQuery();
    }

    public void readByStoreId(int id) throws SQLException {
        String sql = "Select * from Store_Staff_Operates_Store where staff_id = ?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1,id);
        resultSet = ps.executeQuery();
    }


    public void returnResultSet() throws SQLException {
        while (resultSet.next()){
            System.out.println(resultSet.getString("fullname") + ", " + resultSet.getString("phone"));
        }
    }

}

