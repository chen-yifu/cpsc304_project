package drone.delivery.com.company.Model.UI;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import static drone.delivery.com.company.Main.mainFrame;
import static drone.delivery.com.company.Main.userController;

public class customerLogin {
    public JPanel panel1;
    private JTextField emailField1;
    private JTextField passwordField;
    private JButton loginButton;
    private JButton homeButton;

    public customerLogin() {
        homeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mainFrame.getContentPane().removeAll();
                mainFrame.repaint();
                mainFrame.setContentPane(new mainUI().panel1);
                mainFrame.repaint();
                mainFrame.setVisible(true);
            }
        });
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // TODO add login logic here
                // login(String email, String password)
                if (userController.login(emailField1.getText(), passwordField.getText()) == null) {
                    mainFrame.getContentPane().removeAll();
                    mainFrame.repaint();
                    mainFrame.setContentPane(new drone.delivery.com.company.Model.UI.mainUI().panel1);
                    mainFrame.repaint();
                    mainFrame.setVisible(true);
                    System.out.println("Log in failed.");
                } else {
                    mainFrame.getContentPane().removeAll();
                    mainFrame.repaint();
                    mainFrame.setContentPane(new drone.delivery.com.company.Model.UI.customer().panel1);
                    mainFrame.repaint();
                    mainFrame.setVisible(true);
                    System.out.println("Log in successful.");
                }
            }
        });
    }
}
